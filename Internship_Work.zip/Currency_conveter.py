import requests

# Ask user for base currency, target currency, and amount
base_currency = input("Enter base currency: ").upper()
target_currency = input("Enter target currency: ").upper()

try:
    amount = float(input("Enter amount: "))
except ValueError:
    print("Please enter a valid number.")
    exit()
    
# API endpoint to get rates or free exchangerate API
url = f"https://api.exchangerate-api.com/v4/latest/{base_currency}"

try:
    # Fetch data from API
    response = requests.get(url)
    data = response.json()

    # Check if target currency exists
    if target_currency not in data['rates']:
        print("Target currency cannot found. Please check the currency code.")
    else:

        rate = data['rates'][target_currency]
        converted = amount * rate
        print(f"\n {amount} {base_currency} = {converted:.2f} {target_currency}")
except Exception as e:
    print("Error fetching exchange rate:", str(e))
