file_name = input("Enter the text file name (task.txt): ")

try:
    # Read file 
    with open(file_name, 'r', encoding='utf-8') as file:
        content = file.read()

    # Count lines
    line = content.split('\n')
    line_count = len(line)

    # Split content into words
    word_list = content.split()
    word_count = len(word_list)

    # Count characters
    char_count = len(content)
    frequency = {}

    for word in word_list:
        # Remove punctuation and convert to lowercase
        clean_word = word.strip(".,!?;:()[]{}\"'").lower()
        if clean_word in frequency:
            frequency[clean_word] += 1
        else:
            frequency[clean_word] = 1

    # Sort words(descending order)
    sorted_words = sorted(frequency.items(), key=lambda x: x[1], reverse=True)

    # Display results
    print("\nSummary:")
    print(f"Total Lines      : {line_count}")
    print(f"Total Words      : {word_count}")
    print(f"Total Characters : {char_count}")

    print("\nMost Frequent Words:")
    print("-" * 30)
    for word, count in sorted_words[:10]:
        print(f"{word:<15} : {count} time")

except FileNotFoundError:
    print(" File not found. Please check the file name.")
except Exception as e:
    print("Error occur:", str(e))
