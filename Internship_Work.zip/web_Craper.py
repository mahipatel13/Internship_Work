import requests  
from bs4 import BeautifulSoup  

# Step 1: Choose the website to scrape
url = "https://edition.cnn.com/"

# Step 2: Send a request to the website
try:
    response = requests.get(url)
    response.raise_for_status()  # check for any error
except requests.exceptions.RequestException as e:
    print(" Error fetching the website:", e)
    exit()

soup = BeautifulSoup(response.text, 'html.parser')

print("\nTop CNN values Headlines:\n")

# Search for tags that contain headlines
headlines = soup.find_all('h3')

# Step 5: Display the headlines
if not headlines:
    print("No headlines found. The website structure have changed.")
else:
    for i, headline in enumerate(headlines[:10], 1):  # limit to top 10
        print(f"{i}. {headline.get_text(strip=True)}")
