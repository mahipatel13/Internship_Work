import json
import os
from datetime import datetime
from typing import List 
from typing import Dict
from typing import Any

class Task:    
    def __init__(self, description: str, task_id: int = None):
        self.id = task_id if task_id is not None else id(self)
        self.description = description
        self.completed = False
        self.created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.completed_at = None
    
    def mark_completed(self):
        # """Mark task as completed."""
        self.completed = True
        self.completed_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    def mark_incomplete(self):
        # """Mark task as incomplete."""
        self.completed = False
        self.completed_at = None
    
    def to_dict(self) -> Dict[str, Any]:
        # """Convert text to dictionary for serialization."""
        return {
            'id': self.id,
            'description': self.description,
            'completed': self.completed,
            'created_at': self.created_at,
            'completed_at': self.completed_at
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Task':
        # """Task create from dictionary."""
        task = cls(data['description'], data['id'])
        task.completed = data['completed']
        task.created_at = data['created_at']
        task.completed_at = data.get('completed_at')
        return task
    
    def __str__(self) -> str:
        status = "✓" if self.completed else "○"
        return f"[{status}] {self.id}: {self.description}"

class TodoList:
    # """Manages all tasks."""
    
    def __init__(self, filename: str = "tasks.json"):
        self.tasks: List[Task] = []
        self.filename = filename
        self.next_id = 1
        self.load_tasks()
    
    def add_task(self, description: str) ->Task:
        # """Add a new task to in list."""
        if not description.strip():
            raise ValueError("description cannot be empty")
        
        task = Task(description.strip(), self.next_id)
        self.tasks.append(task)
        self.next_id += 1
        self.save_tasks()
        return task
    
    def get_task_by_id(self, task_id: int) ->Task:
        # """Get a task by its ID."""
        for task in self.tasks:
            if task.id == task_id:
                return task
        raise ValueError(f"Task with ID {task_id} not found")
    
    def mark_task_completed(self, task_id: int):
        # """Mark a task as completed."""
        task = self.get_task_by_id(task_id)
        task.mark_completed()
        self.save_tasks()
    
    def mark_task_incomplete(self, task_id: int):
        # """Mark a task as incomplete."""
        task = self.get_task_by_id(task_id)
        task.mark_incomplete()
        self.save_tasks()
    
    def delete_task(self, task_id: int):
        # """Delete a task from the list."""
        task = self.get_task_by_id(task_id)
        self.tasks.remove(task)
        self.save_tasks()
    
    def get_all_tasks(self) -> List[Task]:
        # """Get all tasks."""
        return self.tasks.copy()
    
    def get_completed_tasks(self) -> List[Task]:
        # """Get completed tasks."""
        return [task for task in self.tasks if task.completed]
    
    def get_pending_tasks(self) -> List[Task]:
        # """Get ending tasks."""
        return [task for task in self.tasks if not task.completed]
    
    def save_tasks(self):
        try:
            data = {
                'tasks': [task.to_dict() for task in self.tasks],
                'next_id': self.next_id
            }
            with open(self.filename, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            print(f"Error saving tasks: {e}")
    
    def load_tasks(self):
        try:
            if os.path.exists(self.filename):
                with open(self.filename, 'r') as f:
                    data = json.load(f)
                    self.tasks = [Task.from_dict(task_data) for task_data in data.get('tasks', [])]
                    self.next_id = data.get('next_id', 1)
        except Exception as e:
            print(f"Error loading tasks: {e}")
            self.tasks = []
            self.next_id = 1

class TodoApp:
    # """Main application class with user interface."""
    
    def __init__(self):
        self.todo_list = TodoList()
    
    def display_menu(self):
        # """Display the main menu."""
        print("\n" + "="*50)
        print("   TO-DO LIST MANAGER")
        print("="*50)
        print("1. Add Task")
        print("2. View All Tasks")
        print("3. View Pending Tasks")
        print("4. View Completed Tasks")
        print("5. Mark Task as Completed")
        print("6. Mark Task as Incomplete")
        print("7. Delete Task")
        print("8. Task Statistics")
        print("9. Exit")
        print("="*50)
    
    def display_tasks(self, tasks: List[Task], title: str = "Tasks"):
        # """Display a list of tasks."""
        print(f"\n {title}")
        print("-" * 40)
        
        if not tasks:
            print("No task found.")
            return
        
        for task in tasks:
            print(f"{task}")
            print(f" Created: {task.created_at}")
            if task.completed and task.completed_at:
                print(f"   Completed: {task.completed_at}")
            print()
    
    def add_task(self):
        try:
            description = input("\nEnter task description: ").strip()
            if not description:
                print("Task description can't be empty")
                return
            
            task = self.todo_list.add_task(description)
            print(f"Task added successfully (ID: {task.id})")
        except Exception as e:
            print(f"Error adding task: {e}")
    
    def mark_task_completed(self):
        # """Mark a task as completed."""
        try:
            self.display_tasks(self.todo_list.get_pending_tasks(), "Pending Tasks")
            if not self.todo_list.get_pending_tasks():
                return
            
            task_id = int(input("\nEnter task ID to mark as completed: "))
            self.todo_list.mark_task_completed(task_id)
            print("Task marked as completed!")
        except ValueError as e:
            if "invalid literal" in str(e):
                print("Please enter a valid task ID (number)!")
            else:
                print(f"{e}")
        except Exception as e:
            print(f"Error: {e}")
    
    def mark_task_incomplete(self):
        # """Mark task as incomplete."""
        try:
            self.display_tasks(self.todo_list.get_completed_tasks(), "Completed Tasks")
            if not self.todo_list.get_completed_tasks():
                return
            
            task_id = int(input("\nEnter task ID to mark as incomplete: "))
            self.todo_list.mark_task_incomplete(task_id)
            print("Task incomplete")
        except ValueError as e:
            if "invalid literal" in str(e):
                print("Please enter a valid task ID (number)!")
            else:
                print(f"{e}")
        except Exception as e:
            print(f" Error Occur: {e}")
    
    def delete_task(self):
        # """Delete  task."""
        try:
            self.display_tasks(self.todo_list.get_all_tasks(), "All Task")
            if not self.todo_list.get_all_tasks():
                return
            
            task_id = int(input("\nEnter task ID to delete: "))
            
            # Confirm deletion
            task = self.todo_list.get_task_by_id(task_id)
            confirm = input(f"Are you sure want to delete '{task.description}'? (y/N): ")
            
            if confirm.lower() == 'y':
                self.todo_list.delete_task(task_id)
                print(" Task deleted!")
            else:
                print(" Task deletion cancelled.")
        except ValueError as e:
            if "invalid literal" in str(e):
                print("Please enter a valid task ID (number)!")
            else:
                print(f" {e}")
        except Exception as e:
            print(f" Error: {e}")
    
    def show_statistics(self):

        all_tasks = self.todo_list.get_all_tasks()
        completed_tasks = self.todo_list.get_completed_tasks()
        pending_tasks = self.todo_list.get_pending_tasks()
        
        print("\n TASK STATISTICS")
        print("-" * 30)
        print(f"Total Tasks: {len(all_tasks)}")
        print(f"Completed Tasks: {len(completed_tasks)}")
        print(f"Pending Tasks: {len(pending_tasks)}")
        
        if all_tasks:
            completion_rate = (len(completed_tasks) / len(all_tasks)) * 100
            print(f"Completion Rate: {completion_rate:.1f}%")
        
        print("-" * 30)
    
    def run(self):
        # """main application loop."""
        print("🎉 Welcome to the To-Do List!")
        
        while True:
            try:
                self.display_menu()
                choice = input("Enter your choice (1-9): ").strip()
                
                if choice == '1':
                    self.add_task()
                elif choice == '2':
                    self.display_tasks(self.todo_list.get_all_tasks(), "All Tasks")
                elif choice == '3':
                    self.display_tasks(self.todo_list.get_pending_tasks(), "Pending Tasks")
                elif choice == '4':
                    self.display_tasks(self.todo_list.get_completed_tasks(), "Completed Tasks")
                elif choice == '5':
                    self.mark_task_completed()
                elif choice == '6':
                    self.mark_task_incomplete()
                elif choice == '7':
                    self.delete_task()
                elif choice == '8':
                    self.show_statistics()
                elif choice == '9':
                    print("\n Thank you for using To-Do List Manager!")
                    print("Your tasks have been saved automatically.")
                    break
                else:
                    print(" Invalid choice! Please enter a number between 1-9.")
                
                # Pause before showing menu again
                if choice != '9':
                    input("\nPress Enter to continue...")
                    
            except KeyboardInterrupt:
                print("\n\n bye!")
                break
            except Exception as e:
                print(f" An unexpected error occurred: {e}")

#  Finally run the application
if __name__ == "__main__":
    app = TodoApp()
    app.run()
1