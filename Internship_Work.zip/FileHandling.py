# Ask to user for the file name
file_name = input("Enter the name of the file (example.txt): ")

#ask to user which word find and ehat replace it
word_find = input("Enter the word you want to find: ")
word_replace = input("Enter the word you want to replace it with: ")

try:
    #1: Open the file in read mode
    with open(file_name, 'r') as file:
        content = file.read()

    # 2: Replace the word in the content
    new_content = content.replace(word_find, word_replace)

    # 3: Open the file in write mode to save the changes
    with open(file_name, 'w') as file:
        file.write(new_content)

    print("The word has been replaced and the file updated successfully!")

except FileNotFoundError:
    print("Error occure: The file was not found. Please check the file name and try again.")

except PermissionError:
    print("Error: You don't have permission to r/w this file.")

except Exception as e:
    print("An error occurred:", str(e))
