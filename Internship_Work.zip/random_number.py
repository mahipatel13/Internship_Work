import random  # generate random number

# Print welcome message
print("Hello Gamers! \nWelcome to the Guess the Number Game!")
print("I'm thinking of a number between 1 and 100.")
print("Try to guess it! I'll tell you if it's too high or low.\n")

# Generate a random number 1 to 100
secret_number = random.randint(1, 100)

# Variable to count number of attempts
attempts = 0

# Loop until user guesses the correct number
while True:
    guess = input("Enter your guess: ")
    
    # Check input is a number
    if not guess.isdigit():
        print("Please enter a valid number!")
        continue  
    
    guess = int(guess)  # convert to number
    attempts += 1  

    # Compare guess with the secret number
    if guess < secret_number:
        print("Too low, Try a higher number.")
    elif guess > secret_number:
        print("Too high, Try a lower number.")
    else:
        print(f" Congratulations! You guessed it right in {attempts} tries.")
        break  